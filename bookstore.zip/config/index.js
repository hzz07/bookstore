/*系统配置*/


module.exports={
    /*mongodb 数据库配置*/
    mongodb:{
        auth:false,
        host:'127.0.0.1',
        port:'27017',
        dbname:'bookstore',
        username:'',
        password:'',
    }
}