/*导航栏根据下拉滑块进行样式修改*/
$(window).scroll(function () {
    if ($(".navbar").offset().top > 50) {
        $(".navbar-fixed-top").addClass("top-nav");
    } else {
        $(".navbar-fixed-top").removeClass("top-nav");
    }
})
//执行一个laydate实例
    laydate.render({
    elem: '#test1'
    ,format: 'yyyy年MM月dd日'
});
/*user页面的显示跟隐藏*/
$('.tab-content .pay').hide();
$('.navbar-collapse a').click(function (e) {
    let dianjishumu=$(this).index()
    $('.tab-content .pay').eq(dianjishumu).show(300).siblings().hide(200);
    $('.biaoti a').eq(dianjishumu).addClass('pc_active').siblings().removeClass('pc_active');
})





/*待付款*/
var a = document.getElementById ("pc_1");
var aa = document.getElementById ("pc_2");
var b = document.getElementById ("pc_3");
var bb = document.getElementById ("pc_4");
var c = document.getElementById ("pc_5");
var cc = document.getElementById ("pc_6");
function show(){
    a.style.display="none";
    aa.style.display="none";
    c.style.display="none";
    cc.style.display="none";
    b.style.display="inline";
    bb.style.display="inline";
}
show();
function hide(){
    a.style.display="inline";
    aa.style.display="inline";
    b.style.display="none";
    bb.style.display="none";
}
function next(){
    c.style.display="inline";
    cc.style.display="inline";
    aa.style.display="none";
}
window.onload = function(){
        var s = document.getElementById("pingStar");
        m = document.getElementById("dir"),
            n = s.getElementsByTagName("li"),
            input = document.getElementById("startP");//保存所选值
        clearAll = function(){
            for(var i = 0;i < n.length;i++){
                n[i].className = "";
            }
        }
        for(var i = 0;i < n.length;i++){
            n[i].onclick = function(){
                var q = this.getAttribute("rel");
                clearAll();
                input.value = q;
                for(var i = 0;i < q;i++){
                    n[i].className = "on";
                }
                m.innerHTML = this.getAttribute("title");
            }
            n[i].onmouseover = function(){
                var q = this.getAttribute("rel");
                clearAll();
                for(var i = 0;i < q;i++){
                    n[i].className = "on";
                }
                m.innerHTML = this.getAttribute("title");
            }
            n[i].onmouseout = function(){
                clearAll();
                for(var i = 0;i < input.value;i++){
                    n[i].className = "on";
                }

            }
        }
    }
