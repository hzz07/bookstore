const express = require('express');
const router = express.Router();


/* GET users listing. */
router.get('/user', function(req, res, next) {
    res.render('user', { title: 'user' });
});

module.exports = router;
