var express = require('express');
var router = express.Router();
const Home =require('../controllers/home')
/* GET home page. */
router.get('/', Home.index);

module.exports = router;
