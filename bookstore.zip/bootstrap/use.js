/*
* require 封装*/

module.exports=function (name) {
    return require(name)
};